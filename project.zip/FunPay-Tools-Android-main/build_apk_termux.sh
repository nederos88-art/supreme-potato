#!/data/data/com.termux/files/usr/bin/bash
# =========================================================================
#  Авто-сборка APK в Termux. Запускать ИЗ КОРНЯ проекта (где лежит gradlew).
#  Просто: bash build_apk_termux.sh
# =========================================================================
set -e

echo "==> [1/6] Обновляю Termux и ставим нужные пакеты..."
pkg update -y
pkg install -y openjdk-17 wget unzip

echo "==> [2/6] Готовлю папку под Android SDK..."
export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"
cd "$ANDROID_HOME/cmdline-tools"

if [ ! -d "latest" ]; then
  echo "    качаю command-line tools (это может занять пару минут)..."
  wget -q -O cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cmdtools.zip
  mv cmdline-tools latest
  rm cmdtools.zip
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"

echo "==> [3/6] Принимаю лицензии Android SDK..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "==> [4/6] Ставлю platform-tools, platform-35 и build-tools (качается ~1-2 ГБ)..."
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

echo "==> [5/6] Прописываю путь к SDK в local.properties..."
# возвращаемся в корень проекта (откуда запустили скрипт)
cd "$OLDPWD" 2>/dev/null || true
PROJECT_DIR="$(dirname "$(realpath "$0")")"
cd "$PROJECT_DIR"
echo "sdk.dir=$ANDROID_HOME" > local.properties

echo "==> [6/6] Собираю APK (первый раз Gradle качает зависимости, потерпи)..."
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon --stacktrace

echo ""
echo "========================================================="
echo " ГОТОВО! APK лежит здесь:"
echo " $PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
echo "========================================================="
echo ""
echo "Чтобы скопировать APK в память телефона (папка Download):"
echo "  termux-setup-storage   # один раз, разреши доступ"
echo "  cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/"
