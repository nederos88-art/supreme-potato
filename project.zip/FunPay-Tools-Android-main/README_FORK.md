# FunPay Tools — Open Source Fork (всё разблокировано)

Форк проекта после того, как оригинальный автор покинул его, объявил open-source
и отключил свои серверы (Firebase-лицензии, AI-прокси, статистика). Оплата
PRO-подписки перестала работать, поэтому в этом форке **PRO снят полностью —
все функции бесплатны и работают локально, без обращений к серверам автора**.

## Что изменено

**Убраны мёртвые/платные серверы автора:**
- **Firebase** (`funpay-tools-default-rtdb.firebaseio.com`) — система лицензий и
  онлайн-статистики. Полностью удалена (зависимости + плагин `google-services`).
- **AI-прокси** (`fptools.onrender.com/api/ai`) — бесплатный Render-сервер, который
  «уснул»/умер без оплаты. Обращения к нему отключены.
- **Реклама Start.io** (`com.startapp:inapp-sdk`) — удалена полностью, включая SDK.
- **Кнопки покупки PRO** (`t.me/FPToolsBot`) — убраны, покупать больше нечего.

**Разблокировка:**
- `LicenseManager.hasAccess()` / `isProActive()` теперь всегда `true`.
- AI-клики безлимитны, рекламные «разблокировки на 48ч» больше не нужны.
- Экран «Активировать PRO» заменён на карточку «Всё открыто».

**AI-функции (ответы на отзывы, ИИ-переменные):**
- AI-сервер мёртв, поэтому AI-генерация **отключена**: код автоматически
  откатывается на обычные **шаблоны**, которые работают без сервера.
- Если захочешь вернуть AI — впиши свой OpenAI-совместимый endpoint и ключ в
  `FunPayApi.kt` (метод `rewriteText`, поле `@Url`) и убери ранние `return`
  в трёх функциях `FunPayRepository.kt`: `generateAiReviewReply`,
  `generateReviewReply`, `rewriteMessage`.

**Оставлены рабочими (публичные API):**
- `funpay.com` — ядро приложения (парсинг лотов, чатов, заказов).
- `rmthub.com/api` — публичный поиск по пользователям.
- `translate.googleapis.com` — переводчик.
- `raw.githubusercontent.com/.../donaters.json` — список донатеров (гитхаб).

**Сборка/подпись:**
- Убран захардкоженный keystore автора (`C:/Users/AlliSighs/...`). Debug-сборка
  подписывается стандартным debug-ключом. Для release создай свой keystore.

## Как собрать APK

Нужен интернет (Gradle качает Android SDK и зависимости) и JDK 17+.

### Вариант 1 — Android Studio (проще всего)
1. Открой папку проекта в Android Studio (Ladybug или новее).
2. Дай ей скачать зависимости (Gradle sync).
3. Build → Build App Bundle(s) / APK(s) → **Build APK(s)**.
4. Готовый файл: `app/build/outputs/apk/debug/app-debug.apk`.

### Вариант 2 — командная строка
```bash
# из корня проекта
./gradlew assembleDebug        # Linux/macOS
# или
gradlew.bat assembleDebug      # Windows
```
APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

> Нужен установленный Android SDK. Если сборка ругается на SDK — создай файл
> `local.properties` в корне со строкой `sdk.dir=/путь/к/Android/sdk`
> (в Android Studio это делается автоматически).

### Release-версия (подписанная своим ключом)
1. Создай keystore:
   ```bash
   keytool -genkey -v -keystore my.jks -keyalg RSA -keysize 2048 -validity 10000 -alias mykey
   ```
2. Пропиши его в `app/build.gradle.kts` (секция `signingConfigs`) и верни
   `signingConfig` в `buildTypes.release`.
3. `./gradlew assembleRelease` → `app/build/outputs/apk/release/`.

## Примечание о лицензии
В исходных файлах остались шапки-копирайты автора с запретом на модификацию.
Автор публично (в TG-канале) объявил проект open-source и разрешил форки —
этот форк опирается на то разрешение. Если планируешь публиковать — стоит
сохранить упоминание оригинального автора (XaviersDev / AlliSighs).
