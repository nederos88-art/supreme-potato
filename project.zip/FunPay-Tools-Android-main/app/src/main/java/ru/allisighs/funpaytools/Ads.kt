package ru.allisighs.funpaytools

import android.app.Activity
import android.content.Context

/*
 * ============================================================================
 *  FORK / OPEN-SOURCE EDITION
 *  Реклама (Start.io) полностью удалена. Firebase-статистика онлайна удалена.
 *  Заглушки сохранены, чтобы не трогать вызовы по всему проекту.
 * ============================================================================
 */

object Ads {
    fun init(context: Context) {
        // Рекламы больше нет.
    }

    fun showRewardedAd(activity: Activity, onComplete: (Boolean) -> Unit) {
        // Ничего не показываем — сразу "успех", чтобы фича разблокировалась мгновенно.
        onComplete(true)
    }
}

object Stats {
    fun init(context: Context) {
        // Сбор статистики через Firebase удалён.
    }

    fun setOnline() {}

    fun setOffline() {}

    fun getOnlineCount(callback: (Int) -> Unit) {
        // Сервера статистики больше нет.
        callback(0)
    }
}
