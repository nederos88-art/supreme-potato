package ru.allisighs.funpaytools

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

/*
 * ============================================================================
 *  FORK / OPEN-SOURCE EDITION
 *  Оригинальный автор покинул проект и отключил сервера (Firebase / лицензии).
 *  PRO-подписка полностью снята: все функции разблокированы бесплатно и навсегда.
 *  Никаких обращений к серверам лицензий, никакой рекламы.
 * ============================================================================
 */

enum class PremiumFeature(
    val displayName: String,
    val description: String,
    val emoji: String
) {
    LOTS("Мои лоты", "Редактирование лотов, массовое включение и выключение", "📦"),
    MULTI_ACCOUNT("Мультиаккаунт", "Добавление второго и последующих аккаунтов FunPay", "👥"),
    WIDGET_PROFILE("Виджет Профиль", "Аватарка, рейтинг и ник на рабочем столе", "🪟"),
    RMTHUB("RMTHub", "Глобальный поиск по базе пользователей", "🔧"),
    REVIEW_AI("AI-режим ответа на отзывы", "Генерация ответов через нейросеть. Шаблоны работают бесплатно.", "🤖"),
    AUTO_REFUND("Авто-возврат", "Автоматический возврат средств по заданным условиям", "💸"),
    REVIEW_REQUEST("Просьба отзыва", "Автоматическая просьба оставить отзыв после подтверждения заказа", "⭐"),
    XD_DUMPER("XD Dumper", "Авто-демпинг цен конкурентов", "📉"),
    AI_VARIABLES("ИИ-переменные", "Динамические переменные с обращением к нейросети в шаблонах сообщений", "🧠"),
    CONCURENT("Concurent", "Авто-мониторинг конкурентов и их цен в реальном времени", "👁"),
    AUTO_TICKET("Авто-обращение в ТП", "Автоматическое создание заявок в поддержку FunPay по правилам", "🎫"),
    AUTO_DELIVERY("Автовыдача", "Автоматическая выдача товаров покупателю после оплаты", "📦"),
    AOS("Always On Screen", "Информация на экране блокировки телефона", "🌙")
}

data class LicenseData(
    val key: String = "",
    val deviceId: String = "",
    val activatedAt: Long = 0L,
    val expiresAt: Long = 0L,
    val isRevoked: Boolean = false,
    val purchasedBy: Long = 0L
)

sealed class LicenseState {
    data class Active(val expiresAt: Long, val key: String) : LicenseState()
    object None : LicenseState()
    object Revoked : LicenseState()
}

/*
 *  Заглушка менеджера лицензий.
 *  Всё разблокировано: hasAccess / isProActive всегда true,
 *  AI-клики безлимитны, обращений к серверам нет.
 */
object LicenseManager {

    const val AI_FREE_DAILY = 999_999
    const val AI_AD_BONUS = 999_999

    // Форк всегда считается "PRO навсегда" (expiresAt = 0 => бессрочно)
    var licenseState: LicenseState by mutableStateOf(LicenseState.Active(0L, "OPENSOURCE-FORK"))
        private set

    var currentKey: String by mutableStateOf("OPENSOURCE-FORK")
        private set

    fun init(context: Context) {
        // Ничего не делаем: серверов больше нет, всё открыто локально.
        licenseState = LicenseState.Active(0L, "OPENSOURCE-FORK")
        currentKey = "OPENSOURCE-FORK"
    }

    fun hasAccess(feature: PremiumFeature): Boolean = true
    fun isProActive(): Boolean = true
    fun isAdUnlocked(f: PremiumFeature): Boolean = true
    fun adUnlockHoursLeft(f: PremiumFeature): Long = 0L
    fun applyAdUnlock(f: PremiumFeature) {}

    // AI-клики безлимитны
    fun consumeAiClick(): Boolean = true
    fun aiClicksLeft(): Int = AI_FREE_DAILY
    fun applyAiAdBonus() {}

    fun deviceId(): String = "OPENSOURCE-FORK"

    fun activateKey(key: String, onResult: (Result<Long>) -> Unit) {
        // Любой ключ "активируется" мгновенно и бессрочно.
        currentKey = if (key.isBlank()) "OPENSOURCE-FORK" else key
        licenseState = LicenseState.Active(0L, currentKey)
        onResult(Result.success(0L))
    }

    fun clearLicense() {
        // В форке всё всегда открыто — сброс возвращает к тому же PRO-состоянию.
        licenseState = LicenseState.Active(0L, "OPENSOURCE-FORK")
        currentKey = "OPENSOURCE-FORK"
    }

    fun formatExpiry(ts: Long): String =
        if (ts <= 0L) "Бессрочно"
        else java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault())
            .format(java.util.Date(ts))
}


/* ============================================================================
 *  Composable-заглушки.
 *  Раньше они показывали окна покупки PRO / рекламу. Теперь всё открыто,
 *  поэтому диалоги просто мгновенно "разблокируют" и закрываются, а карточки
 *  показывают статус "всё открыто".
 * ============================================================================ */

@Composable
fun AiLimitDialog(
    theme: AppTheme,
    onDismiss: () -> Unit,
    onBonusGranted: () -> Unit
) {
    // Лимитов больше нет — сразу выдаём "бонус" и закрываем.
    LaunchedEffect(Unit) {
        onBonusGranted()
        onDismiss()
    }
}

@Composable
fun PremiumInterceptor(navController: NavController, theme: AppTheme) {
    // Ничего не перехватываем: все маршруты открыты.
}

@Composable
fun PremiumDialog(
    feature: PremiumFeature,
    theme: AppTheme,
    onDismiss: () -> Unit,
    onUnlocked: () -> Unit
) {
    // Функция уже доступна — сразу разблокируем.
    LaunchedEffect(Unit) {
        onUnlocked()
        onDismiss()
    }
}

@Composable
fun PremiumSwitch(
    feature: PremiumFeature,
    checked: Boolean,
    theme: AppTheme,
    onCheckedChange: (Boolean) -> Unit
) {
    // Обычный переключатель без блокировок.
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = ThemeManager.parseColor(theme.accentColor),
            checkedTrackColor = ThemeManager.parseColor(theme.accentColor).copy(alpha = 0.4f),
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = Color.Gray.copy(alpha = 0.2f)
        )
    )
}

@Composable
fun ProStatusCard(theme: AppTheme) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(theme.borderRadius.dp),
        colors = CardDefaults.cardColors(Color.Transparent),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = Color(0xFF4CAF50).copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("💎", fontSize = 24.sp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        "Всё открыто",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = ThemeManager.parseColor(theme.textPrimaryColor)
                    )
                    Text(
                        "Open-source форк — все функции бесплатны",
                        fontSize = 11.sp,
                        color = Color(0xFF81C784)
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF4CAF50).copy(alpha = 0.12f)
            ) {
                Text(
                    "FREE",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CAF50)
                )
            }
        }
    }
}

@Composable
fun LockBadge(feature: PremiumFeature, theme: AppTheme) {
    // Ничего не блокировано — значков "PRO/замок" больше нет.
}
