/*
 *
 *  * Copyright (c) 2026 XaviersDev (AlliSighs). All rights reserved.
 *  *
 *  * This code is proprietary. Modification, distribution, or use
 *  * of this file without express written permission is strictly prohibited.
 *  * Unauthorized use will be prosecuted.
 *
 */

package ru.allisighs.funpaytools

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*

class FunPayService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var mainRepository: FunPayRepository
    private val lastMessageHashes = mutableMapOf<String, Int>()

    private var wakeLock: PowerManager.WakeLock? = null
    private val processedMessagesCache = mutableMapOf<String, String>()

    
    private val accountJobs = mutableMapOf<String, Job>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        
        mainRepository = FunPayRepository(this)

        
        try {
            PluginEngine.init(this, mainRepository)
        } catch (e: Exception) {
            LogManager.addLog("❌ Ошибка инициализации плагинов: ${e.message}")
        }

        val prefs = getSharedPreferences("funpay_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("app_fully_disabled", false)) {
            LogManager.addLog("⏸ SERVICE: Приложение выключено полностью — сервис не запускается")
            try {
                getSystemService(NotificationManager::class.java)?.cancel(1)
            } catch (_: Exception) {}
            stopSelf()
            return
        }

        WatchdogWorker.start(this)
        try {
            startService(Intent(this, WatchdogDaemon::class.java))
        } catch (e: Exception) {}

        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "FunPayTools::ServiceWakeLock"
            )
            wakeLock?.acquire(24 * 60 * 60 * 1000L)
            LogManager.addLog("🔋 WakeLock активирован")
        } catch (e: Exception) {
            LogManager.addLog("❌ Ошибка WakeLock: ${e.message}")
        }

        createNotificationChannel()
        startForeground(1, createNotification("FunPay Tools работает"))
        LogManager.addLog("✅ SERVICE: Запущен менеджер мультиаккаунтов")
        startWorkLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun startWorkLoop() {
        serviceScope.launch {
            while (isActive) {
                if (!isNetworkAvailable(this@FunPayService)) {
                    updateNotification("Ожидание сети...")
                    delay(25000)
                    continue
                }

                val allAccounts = mainRepository.getAllAccounts()

                
                val validAccounts = allAccounts.filter { it.isActive || it.runInBackground }

                for (account in validAccounts) {
                    if (accountJobs[account.id]?.isActive != true) {
                        LogManager.addLogDebug("🚀 Запуск фонового потока для аккаунта: ${account.username}")
                        accountJobs[account.id] = launchAccountLoop(account.id)
                    }
                }

                
                val validIds = validAccounts.map { it.id }
                accountJobs.keys.toList().forEach { id ->
                    if (id !in validIds) {
                        LogManager.addLogDebug("🛑 Остановка фонового потока для аккаунта: $id")
                        accountJobs[id]?.cancel()
                        accountJobs.remove(id)
                    }
                }

                delay(20000)
            }
        }
    }

    private fun launchAccountLoop(accountId: String): Job = serviceScope.launch {
        val repository = FunPayRepository(this@FunPayService, targetAccountId = accountId)
        val accName = repository.getActiveAccount()?.username ?: accountId

        var lastCleanup = 0L
        var lastWidgetUpdate = 0L
        var lastOnlinePing = 0L

        while (isActive) {
            if (!isNetworkAvailable(this@FunPayService)) {
                delay(25000)
                continue
            }
            val account = repository.getActiveAccount()
            if (account != null) {
                try {
                    val chats = repository.getChats()
                    chats.forEach { chat ->
                        val msgHash = chat.lastMessage.hashCode()
                        if (lastMessageHashes[chat.id] != msgHash) {
                            lastMessageHashes[chat.id] = msgHash

                            val lastSent = FunPayRepository.lastOutgoingMessages[chat.id]
                            // Игнорируем эхо FunPay (когда отправлена картинка, а в чате надпись "Изображение")
                            val isImageEcho = (lastSent == "__image__" && (chat.lastMessage.contains("Изображение", ignoreCase = true) || chat.lastMessage.contains("Image", ignoreCase = true)))

                            if (lastSent != chat.lastMessage && !isImageEcho) {
                                val safeText = chat.lastMessage.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                                // Передаем isMe: false, так как это точно входящее сообщение от собеседника (или от системы)
                                PluginEngine.dispatchEvent("onNewMessage", """{"chatId": "${chat.id}", "username": "${chat.username}", "text": "$safeText", "isMe": false}""")
                            }
                        }
                    }

                    var busySettings = ChatFolderManager.getBusyMode(this@FunPayService)

                    val activeSlot = try {
                        ChatFolderManager.getActiveScheduleSlot(this@FunPayService)
                    } catch (_: Exception) { null }

                    if (activeSlot != null && !busySettings.enabled) {
                        val cal = java.util.Calendar.getInstance()
                        val dayStamp = cal.get(java.util.Calendar.YEAR) * 10000L +
                                cal.get(java.util.Calendar.MONTH) * 100L +
                                cal.get(java.util.Calendar.DAY_OF_MONTH)
                        val slotStamp = (activeSlot.id.hashCode().toLong() and 0xFFFFFFFFL)
                        val scheduledEnabledAt = dayStamp * 1_000_000_000L + slotStamp

                        busySettings = busySettings.copy(
                            enabled = true,
                            enabledAt = scheduledEnabledAt,
                            message = if (activeSlot.overrideMessage && activeSlot.message.isNotBlank())
                                activeSlot.message
                            else busySettings.message,
                            cooldownMinutes = if (activeSlot.overrideCooldown)
                                activeSlot.cooldownMinutes
                            else busySettings.cooldownMinutes
                        )
                    }

                    if (busySettings.enabled) {
                        repository.checkBusyModeReplies(chats, busySettings)
                        if (busySettings.keepRaise) repository.raiseAllLots()
                        if (busySettings.keepAutoResponse) repository.checkAutoResponse(chats)
                        if (busySettings.keepGreeting) repository.checkGreetings(chats)
                    } else {
                        resolveNewUnreadChats(chats, repository)
                        val unreadChatsForDelivery = chats.filter { it.isUnread }
                        for (c in unreadChatsForDelivery) {
                            AutoDeliveryManager.checkAutoDelivery(c, repository, this@FunPayService)
                        }
                        repository.checkAutoResponse(chats)
                        repository.checkGreetings(chats)
                        repository.raiseAllLots()
                        repository.checkOrderConfirmations(chats)
                        repository.checkAutoRefund(chats)
                        repository.checkReviewReplies(chats)
                        repository.runDumperCycle()
                        repository.checkOrderReminders(chats)
                        repository.checkAutoTicketCycle()
                    }

                    try {
                        
                        if (account.isActive) {
                            ConcurentManager.tick(this@FunPayService, repository)
                        }
                    } catch (e: Exception) { }

                    if (repository.getSetting("push_notifications")) {
                        checkPushNotifications(chats)
                    }

                    if (repository.getSetting("always_online")) {
                        if (System.currentTimeMillis() - lastOnlinePing > 4 * 60 * 1000L) {
                            repository.pingOnlineStatus()
                            lastOnlinePing = System.currentTimeMillis()
                        }
                    }

                    if (System.currentTimeMillis() - lastCleanup > 24 * 60 * 60 * 1000L) {
                        repository.cleanupOldProcessedEvents()
                        lastCleanup = System.currentTimeMillis()
                    }


                    if (account.isActive) {
                        if (System.currentTimeMillis() - lastWidgetUpdate > 5 * 60 * 1000L) {
                            try {
                                val profile = repository.getSelfProfile()
                                if (profile != null) {
                                    WidgetManager.saveProfileCache(this@FunPayService, profile)

                                    try {
                                        DynamicAvatarManager.tickFromService(
                                            this@FunPayService,
                                            repository,
                                            profile
                                        )
                                    } catch (e: Exception) {
                                        LogManager.addLogDebug("DynAvatar tick: ${e.message}")
                                    }
                                }
                                WidgetManager.updateAllWidgets(this@FunPayService)
                            } catch (e: Exception) { }
                            lastWidgetUpdate = System.currentTimeMillis()
                        }

                        val unread = chats.count { it.isUnread }
                        val status = if (unread > 0) "Непрочитанных: $unread" else "Работает"
                        updateNotification(status)
                    }

                } catch (e: Exception) {
                    LogManager.addLog("❌ Ошибка в потоке [$accName]: ${e.message}")
                    e.printStackTrace()
                }
            }

            val calendar = java.util.Calendar.getInstance()
            val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
            val isNight = hour in 2..6

            val dumperMinIntervalSec: Int = try {
                val dumper = repository.getDumperSettings()
                if (dumper.enabled && dumper.lots.isNotEmpty()) {
                    dumper.lots.filter { it.enabled }
                        .minOfOrNull { it.updateInterval.coerceAtLeast(1) }
                        ?: Int.MAX_VALUE
                } else Int.MAX_VALUE
            } catch (_: Exception) { Int.MAX_VALUE }

            val concurentMinSec: Int = try {
                val cs = ConcurentManager.getSettings(this@FunPayService)
                if (cs.enabled) {
                    val leftMs = cs.nextPostAt - System.currentTimeMillis()
                    if (leftMs <= 0) 1
                    else (leftMs / 1000).toInt().coerceAtLeast(1)
                } else Int.MAX_VALUE
            } catch (_: Exception) { Int.MAX_VALUE }

            val defaultDelay = if (isNight) 15000L else 6513L
            val tightest = minOf(dumperMinIntervalSec, concurentMinSec)
            val delayTime = if (tightest < Int.MAX_VALUE) {
                (tightest * 1000L).coerceAtMost(defaultDelay).coerceAtLeast(1000L)
            } else defaultDelay

            delay(delayTime)
        }
    }

    private suspend fun resolveNewUnreadChats(chats: List<ChatItem>, repo: FunPayRepository) {
        val authData = repo.getCsrfAndId() ?: return

        val newlyUnread = chats.filter { chat ->
            chat.isUnread &&
                    !FunPayRepository.lastOutgoingMessages.containsKey(chat.id) &&
                    !repo.knownUnreadChats.contains(chat.id)
        }

        for (chat in newlyUnread) {
            repo.knownUnreadChats.add(chat.id)
        }



        val unreadIds = chats.filter { it.isUnread }.map { it.id }.toSet()
        repo.knownUnreadChats.retainAll(unreadIds)
    }

    private fun checkPushNotifications(chats: List<ChatItem>) {
        for (chat in chats) {
            if (chat.isUnread) {
                val lastMsg = chat.lastMessage

                val lastSelf = FunPayRepository.lastOutgoingMessages[chat.id]

                if (lastSelf != null) {
                    if (lastSelf == "__image__") {
                        FunPayRepository.lastOutgoingMessages.remove(chat.id)
                        continue
                    }

                    val cleanIncoming = lastMsg.replace("...", "").trim().lowercase()
                    val cleanSelf = lastSelf.trim().lowercase()
                    if (cleanSelf.contains(cleanIncoming) ||
                        cleanIncoming.contains(cleanSelf) ||
                        cleanSelf.startsWith(cleanIncoming) ||
                        cleanIncoming.startsWith(cleanSelf)) {
                        continue
                    }
                }

                val cachedMsg = processedMessagesCache[chat.id]

                if (cachedMsg != lastMsg) {
                    sendChatNotification(chat)
                    processedMessagesCache[chat.id] = lastMsg
                }
            } else {
                processedMessagesCache.remove(chat.id)
            }
        }
    }

    private fun sendChatNotification(chat: ChatItem) {
        val notificationId = chat.id.hashCode()
        val channelId = "fp_push_channel_v4"

        val replyLabel = "Ответить"
        val remoteInput = RemoteInput.Builder("key_text_reply")
            .setLabel(replyLabel)
            .build()

        val replyIntent = Intent(this, ReplyReceiver::class.java).apply {
            putExtra("chat_id", chat.id)
            putExtra("notification_id", notificationId)
        }

        val replyPendingIntent = PendingIntent.getBroadcast(
            this,
            notificationId,
            replyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        val action = Notification.Action.Builder(
            android.R.drawable.ic_menu_send,
            replyLabel,
            replyPendingIntent
        ).addRemoteInput(remoteInput).build()

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("chat_id", chat.id)
            putExtra("chat_username", chat.username)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, notificationId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setSmallIcon(R.mipmap.ic_launcher_foreground)
            .setContentTitle(chat.username)
            .setContentText(chat.lastMessage)
            .setStyle(Notification.BigTextStyle().bigText(chat.lastMessage))
            .setContentIntent(pendingIntent)
            .addAction(action)
            .setAutoCancel(true)
            .build()

        getSystemService(NotificationManager::class.java).notify(notificationId, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val serviceChannel = NotificationChannel(
                "fp_service",
                "FunPay Tools Core",
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(serviceChannel)

            val soundUri = Uri.parse(
                ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + packageName + "/raw/funpay_push"
            )
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val pushChannel = NotificationChannel(
                "fp_push_channel_v4",
                "Сообщения",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(soundUri, audioAttributes)
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
            }

            manager.deleteNotificationChannel("fp_push_channel_v4")
            manager.createNotificationChannel(pushChannel)
        }
    }

    private fun createNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "fp_service")
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle("FunPay Tools")
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
        notification.flags = notification.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR

        return notification
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(1, createNotification(text))
    }

    override fun onDestroy() {
        serviceScope.cancel()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) { }

        val prefs = getSharedPreferences("funpay_prefs", Context.MODE_PRIVATE)
        val fullyDisabled = prefs.getBoolean("app_fully_disabled", false)

        if (fullyDisabled) {
            LogManager.addLog("⏸ SERVICE: onDestroy при полном выключении — не воскрешаем")
            super.onDestroy()
            return
        }

        LogManager.addLog("🛑 SERVICE: Убит системой, запускаю дефибриллятор")
        if (mainRepository.getSetting("auto_start_on_boot")) {
            val restartIntent = Intent(applicationContext, PhoenixReceiver::class.java).apply {
                action = "ru.allisighs.funpaytools.RESTART_SERVICE"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                this, 2, restartIntent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            alarmManager.setExactAndAllowWhileIdle(
                android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                android.os.SystemClock.elapsedRealtime() + 3000,
                pendingIntent
            )
        }
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        LogManager.addLog("⚠️ SERVICE: Смахнули из недавних. Воскрешаюсь!")

        val prefs = getSharedPreferences("funpay_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("app_fully_disabled", false)) {
            LogManager.addLog("⏸ SERVICE: onTaskRemoved при полном выключении — не воскрешаем")
            super.onTaskRemoved(rootIntent)
            return
        }

        if (mainRepository.getSetting("auto_start_on_boot")) {
            val restartIntent = Intent(applicationContext, PhoenixReceiver::class.java).apply {
                action = "ru.allisighs.funpaytools.RESTART_SERVICE"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                this, 1, restartIntent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager

            alarmManager.setExactAndAllowWhileIdle(
                android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                android.os.SystemClock.elapsedRealtime() + 3000,
                pendingIntent
            )
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
            return activeNetwork.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            val networkInfo = connectivityManager.activeNetworkInfo ?: return false
            @Suppress("DEPRECATION")
            return networkInfo.isConnected
        }
    }
}